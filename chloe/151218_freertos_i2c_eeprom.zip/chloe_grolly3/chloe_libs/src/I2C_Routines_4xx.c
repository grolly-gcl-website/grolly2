#include "stm32f4xx.h"
#include "stm32f4xx_dma.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_i2c.h"
#include "I2C_Routines_4xx.h"


I2C_InitTypeDef  I2C_InitStructure;
__IO uint32_t TimeOut = 0x0;

/* Exported macro ------------------------------------------------------------*/
/* Exported functions ------------------------------------------------------- */
Status I2C_Master_BufferRead(I2C_TypeDef* I2Cx, uint8_t* pBuffer,  uint32_t NumByteToRead, I2C_ProgrammingModel Mode, uint8_t SlaveAddress);
Status I2C_Master_BufferWrite(I2C_TypeDef* I2Cx, uint8_t* pBuffer,  uint32_t NumByteToWrite, I2C_ProgrammingModel Mode, uint8_t SlaveAddress);
void I2C_Slave_BufferReadWrite(I2C_TypeDef* I2Cx,I2C_ProgrammingModel Mode);
void I2C_LowLevel_Init(I2C_TypeDef* I2Cx);
void I2C_DMAConfig(I2C_TypeDef* I2Cx, uint8_t* pBuffer, uint32_t BufferSize, uint32_t Direction);
static void TimeOut_UserCallback(void);
void GCL_I2C_SendData(I2C_TypeDef* I2Cx, uint8_t data);
void GCL_I2C_GenerateSTART(I2C_TypeDef* I2Cx);
void GCL_I2C_Send7bitAddress(I2C_TypeDef* I2Cx, uint8_t addr, uint8_t direction);

// http://electronics.stackexchange.com/questions/65719/i2c-slave-address-not-acknowledged-sometimes
void terminate_i2c(void){
	uint8_t i = 0;
	uint8_t sda = 0;
	sda = (GPIOB->IDR) & (1 << 11);	// test for SDA low
	if (sda == 0) {
		GPIOB->BSRRH |= (1 << 10);	// clock high
		Delay_us_(5);
		for (i=0;i<10;i++) {
			GPIOB->BSRRL |= (1 << 10);	// clock low
			Delay_us_(5);
			GPIOB->BSRRH |= (1 << 10);	// clock high
			Delay_us_(5);
		}
	}
}



Status I2C_Master_BufferWrite(I2C_TypeDef* I2Cx, uint8_t* pBuffer,  uint32_t NumByteToWrite, I2C_ProgrammingModel Mode, uint8_t SlaveAddress){
	TimeOut = I2C_USER_TIMEOUT;
	  while(I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY)) {
	    if((TimeOut) == 0) {
	      I2C_GenerateSTOP(I2Cx, ENABLE);
	    }
	  }

    if (Mode == DMA)  /* I2Cx Master Transmission using DMA */
    {

      GCL_I2C_GenerateSTART(I2Cx);

	  /* Send I2Cx slave Address for write */
	  GCL_I2C_Send7bitAddress(I2Cx, SlaveAddress, I2C_Direction_Transmitter);


	  I2C_DMAConfig(I2Cx, pBuffer, NumByteToWrite, I2C_DIRECTION_TX);

	  /* I2Cx DMA Enable */
	  I2C_DMACmd(I2Cx, ENABLE);

	  /* Enable DMA TX Channel */
	  DMA_Cmd(I2C1_DMA_STREAM_TX, ENABLE);

	  /* Wait until
	   * I2Cx_DMA_STREAM_TX enabled or time out */
	  TimeOut = I2C_USER_TIMEOUT;
//	  while ((DMA_GetCmdStatus(I2C1_DMA_STREAM_TX)!= ENABLE)&&(TimeOut != 0x00))
//	  while ((DMA_GetCmdStatus(I2C1_DMA_STREAM_TX)== ENABLE)&&(TimeOut != 0x00))
	  while (!(I2Cx->SR1 & I2C_SR1_TXE) && TimeOut)
	  {
	//	  TimeOut--;
	  }
	  if(TimeOut == 0)
	  {
	    TimeOut_UserCallback();
	  }

	  /* Wait until DMA Transfer Complete or time out */
	  TimeOut = I2C_USER_TIMEOUT;
	  while ((DMA_GetFlagStatus(I2C1_DMA_STREAM_TX,DMA_FLAG_TCIF6) == RESET)&&(TimeOut != 0x00))
	  {
//		  TimeOut--;
	  }
	  if(TimeOut == 0)
	  {
	    TimeOut_UserCallback();
	  }

	  /* I2Cx DMA Disable */
	  I2C_DMACmd(I2Cx, DISABLE);

	  /* Wait until BTF Flag is set before generating STOP or time out */
	  TimeOut = I2C_USER_TIMEOUT;
	  while ((!I2C_GetFlagStatus(I2Cx,I2C_FLAG_BTF))&&(TimeOut != 0x00))
	  {
//		  TimeOut--;
	  }
	  if(TimeOut == 0)
	  {
	    TimeOut_UserCallback();
	  }

	  /* Send I2Cx STOP Condition */
	  I2C_GenerateSTOP(I2Cx, ENABLE);

	  /* Disable DMA TX Channel */
	  DMA_Cmd(I2C1_DMA_STREAM_TX, DISABLE);

	  /* Wait until I2Cx_DMA_STREAM_TX disabled or time out */
	  TimeOut = I2C_USER_TIMEOUT;
	  while ((DMA_GetCmdStatus(I2C1_DMA_STREAM_TX)!= DISABLE)&&(TimeOut != 0x00))
	  {
//		  TimeOut--;
	  }
	  if(TimeOut == 0)
	  {
	    TimeOut_UserCallback();
	  }

	  /* Clear any pending flag on Tx Stream  */
	  DMA_ClearFlag(I2C1_DMA_STREAM_TX, DMA_FLAG_TCIF6 | DMA_FLAG_FEIF6 | DMA_FLAG_DMEIF6 | \
			  DMA_FLAG_TEIF6 | DMA_FLAG_HTIF6);
//	  terminate_i2c();
    }
    else if (Mode == Interrupt) {

    }
    else if (Mode == 99) {

    }


    else if (Mode == Polling) {


      GCL_I2C_GenerateSTART(I2Cx);


   	  GCL_I2C_Send7bitAddress(I2Cx, SlaveAddress, I2C_Direction_Transmitter);

   	  uint8_t txpntr = 0;
   	  while (txpntr<NumByteToWrite){
		  GCL_I2C_SendData(I2Cx,pBuffer[txpntr++]);
   	  }
	  /* Send I2Cx STOP Condition */
	  I2C_GenerateSTOP(I2Cx, ENABLE);

    }
    else {

    }
    Delay_us_(25000);
}

//uint32_t I2C_Read_DMA(I2C_TypeDef * I2Cx, uint8_t addr, uint8_t amount, uint8_t *buff){
Status I2C_Master_BufferRead(I2C_TypeDef* I2Cx, uint8_t* pBuffer,  uint32_t NumByteToRead, I2C_ProgrammingModel Mode, uint8_t SlaveAddress){
    if (Mode == DMA)  /* I2Cx Master Transmission using DMA */
    {
	  /* Enable DMA NACK automatic generation */
	  I2C_DMALastTransferCmd(I2Cx, ENABLE);

	  /* Send I2Cx START condition */
	  GCL_I2C_GenerateSTART(I2Cx);

	  /* Send I2Cx slave Address for write */
	  GCL_I2C_Send7bitAddress(I2Cx, SlaveAddress, I2C_Direction_Receiver);
	  //I2C_Send7bitAddress(I2Cx, SlaveAddress, I2C_Direction_Receiver);


	  /* I2Cx DMA Enable */
	  I2C_DMACmd(I2Cx, ENABLE);

	  /* Enable DMA RX Channel */
//	  DMA_Cmd(I2C1_DMA_STREAM_RX, ENABLE);

	  I2C_DMAConfig(I2Cx, pBuffer, NumByteToRead, I2C_DIRECTION_RX);

	  /* Wait until I2Cx_DMA_STREAM_RX enabled or time out */
	  TimeOut = I2C_USER_TIMEOUT;
	  while ((DMA_GetCmdStatus(I2C1_DMA_STREAM_RX)!= ENABLE)&&(TimeOut != 0x00))
	  {
		  TimeOut--;
	  }
	  if(TimeOut == 0)
	  {
	    TimeOut_UserCallback();
	  }

	  /* Transfer complete or time out */
	  TimeOut = I2C_USER_TIMEOUT;
	  while ((DMA_GetFlagStatus(I2C1_DMA_STREAM_RX,DMA_FLAG_TCIF0)==RESET)&&(TimeOut != 0x00))
	  {
		  TimeOut--;
	  }
	  if(TimeOut == 0)
	  {
	    TimeOut_UserCallback();
	  }
	  /* Send I2Cx STOP Condition */
	  I2C_GenerateSTOP(I2Cx, ENABLE);

	  /* Disable DMA RX Channel */
	  DMA_Cmd(I2C1_DMA_STREAM_RX, DISABLE);

	  /* Wait until I2Cx_DMA_STREAM_RX disabled or time out */
	  TimeOut = I2C_USER_TIMEOUT;
	  while ((DMA_GetCmdStatus(I2C1_DMA_STREAM_RX)!= DISABLE)&&(TimeOut != 0x00))
	  {
		  TimeOut--;
	  }
	  if(TimeOut == 0)
	  {
	    TimeOut_UserCallback();
	  }

	  /* Disable I2C DMA request */
	  I2C_DMACmd(I2Cx,DISABLE);

	  /* Clear any pending flag on Rx Stream  */
	  DMA_ClearFlag(I2C1_DMA_STREAM_RX, DMA_FLAG_TCIF0 | DMA_FLAG_FEIF0 | DMA_FLAG_DMEIF0 | \
			  DMA_FLAG_TEIF0 | DMA_FLAG_HTIF0);
    }
    else if (Mode == Interrupt) {

    }
    else if (Mode == Polling) {

    }
    else {

    }
}


// pervyj kandidat na rabochest', sdelan po ishodnikam primerov stdlib f4
void I2C_LowLevel_Init(I2C_TypeDef* I2Cx) {
	  DMA_InitTypeDef  DMA_InitStructure;
	  GPIO_InitTypeDef  GPIO_InitStructure;

	  /* RCC Configuration */
	  /*I2C Peripheral clock enable */
	  RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);

	  /*SDA GPIO clock enable */
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	  /* Reset I2Cx IP */
	  RCC_APB1PeriphResetCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	  /* Release reset signal of I2Cx IP */
	  RCC_APB1PeriphResetCmd(RCC_AHB1Periph_GPIOB, DISABLE);

	  /* Enable the DMA clock */
	  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_DMA1, ENABLE);

	  /* GPIO Configuration */
	  /*Configure I2C SCL pin */
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	  GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
	  GPIO_InitStructure.GPIO_PuPd  = GPIO_PuPd_NOPULL;
	  GPIO_Init(GPIOB, &GPIO_InitStructure);

	  /*Configure I2C SDA pin */
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	  GPIO_Init(GPIOB, &GPIO_InitStructure);

	  /* Connect PXx to I2C_SCL */
	  GPIO_PinAFConfig(GPIOB, GPIO_PinSource6, GPIO_AF_I2C1);

	  /* Connect PXx to I2C_SDA */
	  GPIO_PinAFConfig(GPIOB, GPIO_PinSource9, GPIO_AF_I2C1);

	  /* DMA Configuration */
	  /* Clear any pending flag on Tx Stream  */
	  DMA_ClearFlag(I2C1_DMA_STREAM_TX, DMA_FLAG_TCIF6 | DMA_FLAG_FEIF6 | DMA_FLAG_DMEIF6 | \
			  DMA_FLAG_TEIF6 | DMA_FLAG_HTIF6);

	  /* Clear any pending flag on Rx Stream  */
	  DMA_ClearFlag(I2C1_DMA_STREAM_RX, DMA_FLAG_TCIF0 | DMA_FLAG_FEIF0 | DMA_FLAG_DMEIF0 | \
			  DMA_FLAG_TEIF0 | DMA_FLAG_HTIF0);

	  /* Disable the I2C Tx DMA stream */
	  DMA_Cmd(I2C1_DMA_STREAM_TX, DISABLE);
	  /* Configure the DMA stream for the I2C peripheral TX direction */
	  DMA_DeInit(I2C1_DMA_STREAM_TX);

	  /* Disable the I2C Rx DMA stream */
	  DMA_Cmd(I2C1_DMA_STREAM_RX, DISABLE);
	  /* Configure the DMA stream for the I2C peripheral RX direction */
	  DMA_DeInit(I2C1_DMA_STREAM_RX);

	  /* Initialize the DMA_Channel member */
	  DMA_InitStructure.DMA_Channel = DMA_Channel_1;

	  /* Initialize the DMA_PeripheralBaseAddr member */
	  DMA_InitStructure.DMA_PeripheralBaseAddr = ((uint32_t)I2C1_DR_Address);

	  /* Initialize the DMA_PeripheralInc member */
	  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;

	  /* Initialize the DMA_MemoryInc member */
	  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;

	  /* Initialize the DMA_PeripheralDataSize member */
	  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;

	  /* Initialize the DMA_MemoryDataSize member */
	  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;

	  /* Initialize the DMA_Mode member */
	  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;

	  /* Initialize the DMA_Priority member */
	  DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;

	  /* Initialize the DMA_FIFOMode member */
	  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable;

	  /* Initialize the DMA_FIFOThreshold member */
	  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;

	  /* Initialize the DMA_MemoryBurst member */
	  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;

	  /* Initialize the DMA_PeripheralBurst member */
	  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;

	  /* Init DMA for Reception */
	   /* Initialize the DMA_DIR member */
	   DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
	   /* Initialize the DMA_Memory0BaseAddr member */
	   DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)0;
	   /* Initialize the DMA_BufferSize member */
	   DMA_InitStructure.DMA_BufferSize = I2C_RXBUFFERSIZE;
	   DMA_DeInit(I2C1_DMA_STREAM_RX);
	   DMA_Init(I2C1_DMA_STREAM_RX, &DMA_InitStructure);

	  /* Init DMA for Transmission */
	   /* Initialize the DMA_DIR member */
	   DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
	   /* Initialize the DMA_Memory0BaseAddr member */
	   DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)0;
	   /* Initialize the DMA_BufferSize member */
	   DMA_InitStructure.DMA_BufferSize = I2C_TXBUFFERSIZE;
	   DMA_DeInit(I2C1_DMA_STREAM_TX);
	   DMA_Init(I2C1_DMA_STREAM_TX, &DMA_InitStructure);

	   /* Configure I2C Filters */
	   I2C_AnalogFilterCmd(I2C1,ENABLE);
	   I2C_DigitalFilterConfig(I2C1,0x0F);

	   /* I2C Struct Initialize */
	   I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
	   I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
	   I2C_InitStructure.I2C_OwnAddress1 = 0x01;
	   I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
	   I2C_InitStructure.I2C_ClockSpeed = 100000;

	   I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;

	   /* I2C Initialize */
	   I2C_Init(I2Cx, &I2C_InitStructure);



	  /* I2C ENABLE */
	  I2C_Cmd(I2Cx, ENABLE);
}

void GCL_I2C_init(void) {
	// STMicroelectronics IORoutines example

	// NVIC_Configuration()
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);

	NVIC_SetPriority(I2C1_EV_IRQn, 0x01);
	NVIC_EnableIRQ(I2C1_EV_IRQn);

	NVIC_SetPriority(I2C1_ER_IRQn, 0x02);
	NVIC_EnableIRQ(I2C1_ER_IRQn);

	I2C_LowLevel_Init(I2C1); // make an init on low level

	NVIC_SetPriority(I2C2_EV_IRQn, 0x01);
	NVIC_EnableIRQ(I2C2_EV_IRQn);

	NVIC_SetPriority(I2C2_ER_IRQn, 0x02);
	NVIC_EnableIRQ(I2C2_ER_IRQn);

	I2C_LowLevel_Init(I2C2);
}


void I2C_DMAConfig(I2C_TypeDef* I2Cx, uint8_t* pBuffer, uint32_t BufferSize, uint32_t Direction)
{
	DMA_InitTypeDef  DMA_InitStructure;

	  /* Initialize the DMA_Channel member */
	  DMA_InitStructure.DMA_Channel = I2Cx_DMA_CHANNEL;

	  /* Initialize the DMA_PeripheralBaseAddr member */
	  DMA_InitStructure.DMA_PeripheralBaseAddr = I2C1_DR_Address;		// ATTENTION!!!

	  /* Initialize the DMA_PeripheralInc member */
	  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;

	  /* Initialize the DMA_MemoryInc member */
	  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;

	  /* Initialize the DMA_PeripheralDataSize member */
	  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;

	  /* Initialize the DMA_MemoryDataSize member */
	  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;

	  /* Initialize the DMA_Mode member */
	  DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;

	  /* Initialize the DMA_Priority member */
	  DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;

	  /* Initialize the DMA_FIFOMode member */
	  DMA_InitStructure.DMA_FIFOMode = DMA_FIFOMode_Enable;

	  /* Initialize the DMA_FIFOThreshold member */
	  DMA_InitStructure.DMA_FIFOThreshold = DMA_FIFOThreshold_Full;

	  /* Initialize the DMA_MemoryBurst member */
	  DMA_InitStructure.DMA_MemoryBurst = DMA_MemoryBurst_Single;

	  /* Initialize the DMA_PeripheralBurst member */
	  DMA_InitStructure.DMA_PeripheralBurst = DMA_PeripheralBurst_Single;








    // Initialize the DMA with the new parameters
    if (Direction == I2C_DIRECTION_TX)
    {
        // Configure the DMA Tx Channel with the buffer address and the buffer size
        DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)pBuffer;
        DMA_InitStructure.DMA_DIR = DMA_DIR_MemoryToPeripheral;
        DMA_InitStructure.DMA_BufferSize = (uint32_t)BufferSize;

        if (I2Cx == I2C1)
        {
            DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)I2C1_DR_Address;
            DMA_Cmd(I2C1_DMA_STREAM_TX, DISABLE);
            DMA_Init(I2C1_DMA_STREAM_TX, &DMA_InitStructure);
            DMA_Cmd(I2C1_DMA_STREAM_TX, ENABLE);
        }
        else
        {
            DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)I2C2_DR_Address;
            DMA_Cmd(I2C2_DMA_STREAM_TX, DISABLE);
            DMA_Init(I2C2_DMA_STREAM_TX, &DMA_InitStructure);
            DMA_Cmd(I2C2_DMA_STREAM_TX, ENABLE);
        }
    }
    else // Reception
    {
        // Configure the DMA Rx Channel with the buffer address and the buffer size
        DMA_InitStructure.DMA_Memory0BaseAddr = (uint32_t)pBuffer;
        DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralToMemory;
        DMA_InitStructure.DMA_BufferSize = (uint32_t)BufferSize;
        if (I2Cx == I2C1)
        {

            DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)I2C1_DR_Address;
            DMA_Cmd(I2C1_DMA_STREAM_RX, DISABLE);
            DMA_Init(I2C1_DMA_STREAM_RX, &DMA_InitStructure);
            DMA_Cmd(I2C1_DMA_STREAM_RX, ENABLE);
        }

        else
        {
            DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)I2C2_DR_Address;
            DMA_Cmd(I2C2_DMA_STREAM_RX, DISABLE);
            DMA_Init(I2C2_DMA_STREAM_RX, &DMA_InitStructure);
            DMA_Cmd(I2C2_DMA_STREAM_RX, ENABLE);
        }

    }
}


static void TimeOut_UserCallback(void)
{
  /* User can add his own implementation to manage TimeOut Communication failure */
  /* Block communication and all processes */
/*  while (1)
  {
  } */
}



/*
 * GCL_I2C_xxx I2C drivers for GCL projects
 * http://gcl.engineering
 *
 *
 *
 */


void GCL_I2C_SendData(I2C_TypeDef* I2Cx, uint8_t data){
	uint32_t timeout = I2C_USER_TIMEOUT; /* Initialize timeout value */

	/* Send I2C1 location address LSB */
	I2C_SendData(I2C1,data);

	/* Test on I2C1 EV8 and clear it */
	while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_TRANSMITTED))
	{
		/* If the timeout delay is exeeded, exit with error code */
		if((TimeOut--) == 0)
		{
			TimeOut_UserCallback();
		}
	}
}

void GCL_I2C_Send7bitAddress(I2C_TypeDef* I2Cx, uint8_t addr, uint8_t direction){
	uint32_t mode = 0;
	uint32_t timeout = 0;
	if (direction==I2C_Direction_Transmitter) {
		mode = I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED;
	}
	if (direction==I2C_Direction_Receiver) {
		mode = I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED;
	}
	/* Send I2Cx slave Address for write */
	I2C_Send7bitAddress(I2Cx, addr, direction);

	/* Test on I2Cx EV6 and clear it or time out */
	timeout = I2C_USER_TIMEOUT;
	while ((!I2C_CheckEvent(I2Cx, mode))&&(timeout != 0x00))
	{
	//	  TimeOut--;
	}
	if(timeout == 0)
	{
		TimeOut_UserCallback();
	}
}

void GCL_I2C_GenerateSTART(I2C_TypeDef* I2Cx){
	uint32_t timeout = I2C_USER_TIMEOUT; /* Initialize timeout value */
	I2C_GenerateSTART(I2Cx, ENABLE);
	/* Test on I2Cx EV5 and clear it */
	while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT))
	{
		/* If the timeout delay is exceeded, exit with error code */
		if ((timeout--) == 0){

		}
	}
}

uint8_t Read_24Cxx(uint16_t Addr, uint8_t Mem_Type)
{
  uint32_t timeout = 100;
  uint8_t Data = 0;

  uint8_t upper_addr = 0;
  uint8_t lower_addr = 0;

  lower_addr = (uint8_t)((0x00FF)&Addr);

  Addr = Addr>>8;
  upper_addr = (uint8_t)((0x00FF)&Addr);

  /* Generate the Start Condition */
  GCL_I2C_GenerateSTART(I2C1);
  GCL_I2C_Send7bitAddress(I2C1, 0xa0, I2C_Direction_Transmitter);

  /* Send I2C1 location address LSB */
  GCL_I2C_SendData(I2C1, upper_addr);

  Delay_us_(1000000);

  /* Send I2C1 location address LSB */
  GCL_I2C_SendData(I2C1, lower_addr);

  Delay_us_(100000);

  /* Generate the Start Condition */
  GCL_I2C_GenerateSTART(I2C1);

  GCL_I2C_Send7bitAddress(I2C1, 0xa0, I2C_Direction_Receiver);

          /* Prepare an NACK for the next data received */
          I2C_AcknowledgeConfig(I2C1, DISABLE);

          /* Test on I2C1 EV7 and clear it */
          timeout = 100; /* Initialize timeout value */
          while(!I2C_CheckEvent(I2C1, I2C_EVENT_MASTER_BYTE_RECEIVED))
          {
                /* If the timeout delay is exeeded, exit with error code */
                 if ((timeout--) == 0) {

                 }
          }

          I2C_GenerateSTOP(I2C1, ENABLE);

          /* Receive the Data */
          Data = I2C_ReceiveData(I2C1);

          /* return the read data */
          return Data;
}
