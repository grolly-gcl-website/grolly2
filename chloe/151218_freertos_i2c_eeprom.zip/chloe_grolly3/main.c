#include "main.h"
#include "eeprom.h"
#include "delays.h"
#include "stm32f4xx_i2c.h"
#include "I2C_Routines_4xx.h"

#include "usb_cdc.h"
#define USE_ACCURATE_TIME

void vTaskLED5(void *pvParameters);
void vTaskLED6(void *pvParameters);

extern void PrintChar(int c);

static void Fill_Buffer(uint8_t *pBuffer, uint16_t BufferLength)
{
  uint16_t index = 0;

  /* Put in global buffer same values */
  for (index = 0; index < BufferLength; index++ )
  {
    pBuffer[index] = 0x00;
  }
}

uint8_t buf[10];

int main(void)
{

	Fill_Buffer(buf, 10);


	 /* Unlock the Flash Program Erase controller */
	FLASH_Unlock();

	/* EEPROM Init */
	EE_Init();

	SystemInit();

	GCL_I2C_init();



	buf[0] = 0;
	buf[1] = 1;
	buf[2] = 47;

	// eeprom write
	I2C_Master_BufferWrite(I2C1, buf,  3, DMA, 0xa0);		// write to eeprom 24c32

	I2C_Master_BufferWrite(I2C1, buf,  3, DMA, 0xa0);		// write to eeprom 24c32

	I2C_Master_BufferWrite(I2C1, buf,  3, DMA, 0xa0);		// write to eeprom 24c32


	// eeprom read
	buf[0] = Read_24Cxx(1, 0);	// read 24xx EEPROM

//NW	I2C_Master_BufferRead(I2C1, buf,  3, DMA, 0xa0);		// read byte
//NW	I2C_Master_BufferRead(I2C1, buf,  9, DMA, 0xa0);		// read byt

	STM32F4_Discovery_LEDInit(LED6);
	STM32F4_Discovery_LEDInit(LED5);
	STM32F4_Discovery_LEDInit(LED4);
	STM32F4_Discovery_LEDInit(LED3);
	STM32F4_Discovery_LEDOff(LED3);
	STM32F4_Discovery_LEDOff(LED4);
	STM32F4_Discovery_LEDOff(LED5);
	STM32F4_Discovery_LEDOff(LED6);
	usb_init();
	delay(10000);
//	I2C_SendData();
	xTaskCreate( vTaskLED5, ( signed char * ) "LED5", configMINIMAL_STACK_SIZE, NULL, 2, ( xTaskHandle * ) NULL);
	xTaskCreate( vTaskLED6, ( signed char * ) "LED6", configMINIMAL_STACK_SIZE, NULL, 2, ( xTaskHandle * ) NULL);

	vTaskStartScheduler();
}


void vTaskLED5(void *pvParameters) {
	for (;;) {
		STM32F4_Discovery_LEDOn(LED5);
		vTaskDelay(500);
		STM32F4_Discovery_LEDOff(LED5);
		vTaskDelay(500);
	}
}

void vTaskLED6(void *pvParameters) {
	for (;;) {
		STM32F4_Discovery_LEDOn(LED6);
		vTaskDelay(321);
		STM32F4_Discovery_LEDOff(LED6);
		vTaskDelay(321);
		PrintChar((buf[0]/10)+48);
		PrintChar((buf[0]%10)+48);
		PrintChar((buf[1]/10)+48);
		PrintChar((buf[1]%10)+48);
		PrintChar((buf[2]/10)+48);
		PrintChar((buf[2]%10)+48);
	}
}


