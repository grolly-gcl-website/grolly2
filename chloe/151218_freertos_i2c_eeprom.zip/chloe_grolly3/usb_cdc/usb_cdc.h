#ifndef __USB_CDC_H
#define __USB_CDC_H


#include "usbd_cdc_core.h"
#include "usbd_usr.h"
#include "usbd_desc.h"
#include "FreeRTOS.h"
#include "task.h"

int usb_cmdread(void);
void usb_init(void);
void usb_tick(void);
void vTaskUSB_cmdRead(void *pvParameters);
void vTaskUSB_cmdExec(void *pvParameters);
void PrintChar(int c);
#endif
