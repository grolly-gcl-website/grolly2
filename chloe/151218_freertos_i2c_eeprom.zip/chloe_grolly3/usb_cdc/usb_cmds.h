#ifndef __USB_CMDS__
#define __USB_CMDS__

void vTaskSimpleCMD(void *pvParameters);

#endif
