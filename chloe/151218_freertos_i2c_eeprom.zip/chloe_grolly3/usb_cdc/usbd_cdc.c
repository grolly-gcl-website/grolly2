#ifdef USB_OTG_HS_INTERNAL_DMA_ENABLED 
#pragma     data_alignment = 4 
#endif /* USB_OTG_HS_INTERNAL_DMA_ENABLED */

/* Includes ------------------------------------------------------------------*/
#include "usbd_cdc.h"
#include "stm32f4_discovery.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/* These are external variables imported from CDC core to be used for IN 
   transfer management. */
extern uint8_t  APP_Rx_Buffer []; /* Write CDC received data in this buffer.
                                     These data will be sent over USB IN endpoint
                                     in the CDC core functions. */
extern uint32_t APP_Rx_ptr_in;    /* Increment this pointer or roll it back to
                                     start address when writing received data
                                     in the buffer APP_Rx_Buffer. */

uint8_t usb_rx[64];
uint8_t usb_cmd[64];
int usb_cmd_cursor=0;
int USB_RX_BUFFER_LEN=64;
/* Private function prototypes -----------------------------------------------*/

static uint16_t cdc_Init     (void);
static uint16_t cdc_DeInit   (void);
static uint16_t cdc_Ctrl     (uint32_t Cmd, uint8_t* Buf, uint32_t Len);
static uint16_t cdc_DataTx   (uint8_t* Buf, uint32_t Len);
static uint16_t cdc_DataRx   (uint8_t* Buf, uint32_t Len);

CDC_IF_Prop_TypeDef cdc_fops =
{
  cdc_Init,
  cdc_DeInit,
  cdc_Ctrl,
  cdc_DataTx,
  cdc_DataRx
};

/* Private functions ---------------------------------------------------------*/
/**
  * @brief  cdc_Init
  *         Initializes the Media on the STM32
  * @param  None
  * @retval Result of the opeartion (USBD_OK in all cases)
  */
static uint16_t cdc_Init(void)
{
  return USBD_OK;
}


static uint16_t cdc_DeInit(void)
{

  return USBD_OK;
}


/**
  * @brief  cdc_Ctrl
  *         Manage the CDC class requests
  * @param  Cmd: Command code            
  * @param  Buf: Buffer containing command data (request parameters)
  * @param  Len: Number of data to be sent (in bytes)
  * @retval Result of the opeartion (USBD_OK in all cases
  */
//not really necessary for this example
static uint16_t cdc_Ctrl (uint32_t Cmd, uint8_t* Buf, uint32_t Len)
{ 
  switch (Cmd)
  {
  case SEND_ENCAPSULATED_COMMAND:
    /* Not  needed for this driver */
    break;

  case GET_ENCAPSULATED_RESPONSE:
    /* Not  needed for this driver */
    break;

  case SET_COMM_FEATURE:
    /* Not  needed for this driver */
    break;

  case GET_COMM_FEATURE:
    /* Not  needed for this driver */
    break;

  case CLEAR_COMM_FEATURE:
    /* Not  needed for this driver */
    break;

  case SET_LINE_CODING:

    break;

  case GET_LINE_CODING:

    break;

  case SET_CONTROL_LINE_STATE:
    /* Not  needed for this driver */
    break;

  case SEND_BREAK:
    /* Not  needed for this driver */
    break;    
    
  default:
    break;
  }

  return USBD_OK;
}

/**
  * @brief  cdc_DataTx
  *         CDC received data to be send over USB IN endpoint are managed in 
  *         this function.
  * @param  Buf: Buffer of data to be sent
  * @param  Len: Number of data to be sent (in bytes)
  * @retval Result of the opeartion: USBD_OK
  */
static uint16_t cdc_DataTx (uint8_t* Buf, uint32_t Len)
{

	uint32_t i;
	//loop through buffer
	for( i = 0; i < Len; i++ )
	{
		//push data into transfer buffer
		APP_Rx_Buffer[APP_Rx_ptr_in] = Buf[i] ;
		//increase pointer value
		APP_Rx_ptr_in++;
		/* To avoid buffer overflow */
		if(APP_Rx_ptr_in == APP_RX_DATA_SIZE)
		{
			APP_Rx_ptr_in = 0;
		}
	}

	return USBD_OK;
}

void clear_cmd_buff(){
	int i;
	for(i=0;i<USB_RX_BUFFER_LEN;i++){
		usb_cmd[i] = 0;
	}
}

static uint16_t cdc_DataRx (uint8_t* Buf, uint32_t Len)
{
	uint32_t i;
	for (i = 0; i < Len; i++)
	{
		uint8_t c = Buf[i];
		if( c == '\r' ){
			usb_cmd_exec((void*)usb_cmd);
			usb_cmd_cursor=0;
			clear_cmd_buff();
		}else if( c != 0 ){
			usb_cmd[usb_cmd_cursor] = c;
			usb_cmd_cursor++;
		}
	}
	return USBD_OK;
}


//this function is run when the user button is pushed
void DISCOVERY_EXTI_IRQHandler(void)
{
	uint8_t buffer[] = "terve"; // "terve" is hello in finnish :)
	cdc_DataTx (buffer, (uint32_t) 5);
}



/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
