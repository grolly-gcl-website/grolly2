#include "stm32f4xx.h"

/* Registers location */
#define DS1307_SECONDS				0x00
#define DS1307_MINUTES				0x01
#define DS1307_HOURS				0x02
#define DS1307_DAY					0x03
#define DS1307_DATE					0x04
#define DS1307_MONTH				0x05
#define DS1307_YEAR					0x06
#define DS1307_CONTROL				0x07

#define DS1307_I2C_ADDR				0xD0		// I2C bus RTC clock address

#define DS1307_I2Cx					I2C1

typedef enum {
	GCL_RTC1307_Result_Ok = 0x00,         /*!< Everything OK */
	GCL_RTC1307_Result_Error,             /*!< An error occurred */
	GCL_RTC1307_Result_DeviceNotConnected /*!< Device is not connected */
} GCL_RTC1307_Result_t;

typedef struct {
	uint8_t seconds; /*!< Seconds parameter, from 00 to 59 */
	uint8_t minutes; /*!< Minutes parameter, from 00 to 59 */
	uint8_t hours;   /*!< Hours parameter, 24Hour mode, 00 to 23 */
	uint8_t day;     /*!< Day in a week, from 1 to 7 */
	uint8_t date;    /*!< Date in a month, 1 to 31 */
	uint8_t month;   /*!< Month in a year, 1 to 12 */
	uint8_t year;    /*!< Year parameter, 00 to 99, 00 is 2000 and 99 is 2099 */
} GCL_RTC1307_Time_t;


void GCL_RTC1307_SetDateTime(GCL_RTC1307_Time_t* time);
void GCL_RTC1307_GetDateTime(GCL_RTC1307_Time_t* time);
uint8_t GCL_RTC1307_Bin2Bcd(uint8_t bin);
uint8_t GCL_RTC1307_Bcd2Bin(uint8_t bcd);
uint8_t GCL_RTC1307_CheckMinMax(uint8_t val, uint8_t min, uint8_t max);
int GCL_RTC1307_Bcd2Bin_int(uint8_t bcd);
