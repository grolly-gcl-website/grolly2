#include "ds1307.h"
#include "I2C_Routines_4xx.h"

void GCL_RTC1307_SetDateTime(GCL_RTC1307_Time_t* time);
void GCL_RTC1307_GetDateTime(GCL_RTC1307_Time_t* time);
uint8_t GCL_RTC1307_Bin2Bcd(uint8_t bin);
uint8_t GCL_RTC1307_Bcd2Bin(uint8_t bcd);
uint8_t GCL_RTC1307_CheckMinMax(uint8_t val, uint8_t min, uint8_t max);

void GCL_RTC1307_Init(void) {

//	TM_I2C_Init(DS1307_I2C, DS1307_I2C_PINSPACK, DS1307_I2C_CLOCK);

	/* Check if device is connected */
	if (!GCL_I2C_IsDeviceConnected(DS1307_I2Cx, DS1307_I2C_ADDR)) {
		return GCL_RTC1307_Result_DeviceNotConnected;
	}
}


void GCL_RTC1307_SetDateTime(GCL_RTC1307_Time_t* time) {
	uint8_t data[8];

	/* Format data */
	data[0] = DS1307_SECONDS;	// first register address, in sequence to read
	data[DS1307_SECONDS+1] = GCL_RTC1307_Bin2Bcd(GCL_RTC1307_CheckMinMax(time->seconds, 0, 59));
	data[DS1307_MINUTES+1] = GCL_RTC1307_Bin2Bcd(GCL_RTC1307_CheckMinMax(time->minutes, 0, 59));
	data[DS1307_HOURS+1] = GCL_RTC1307_Bin2Bcd(GCL_RTC1307_CheckMinMax(time->hours, 0, 23));
	data[DS1307_DAY+1] = GCL_RTC1307_Bin2Bcd(GCL_RTC1307_CheckMinMax(time->day, 1, 7));
	data[DS1307_DATE+1] = GCL_RTC1307_Bin2Bcd(GCL_RTC1307_CheckMinMax(time->date, 1, 31));
	data[DS1307_MONTH+1] = GCL_RTC1307_Bin2Bcd(GCL_RTC1307_CheckMinMax(time->month, 1, 12));
	data[DS1307_YEAR+1] = GCL_RTC1307_Bin2Bcd(GCL_RTC1307_CheckMinMax(time->year, 0, 99));

	/* Write to device */
	I2C_Master_BufferWrite(I2C1, data,  8, DMA, DS1307_I2C_ADDR);
//	TM_I2C_WriteMulti(DS1307_I2C, DS1307_I2C_ADDR, DS1307_SECONDS, data, 7);
}

void GCL_RTC1307_GetDateTime(GCL_RTC1307_Time_t* time) {
	uint8_t data[8];
	data[0] = 0x00;
	/* Read multi bytes */
//	TM_I2C_ReadMulti(DS1307_I2C, DS1307_I2C_ADDR, DS1307_SECONDS, data, 7);
	I2C_Master_BufferRead(I2C1, data,  7, Polling, DS1307_I2C_ADDR);

	/* Fill data */
	time->seconds = GCL_RTC1307_Bcd2Bin(data[DS1307_SECONDS]);
	time->minutes = GCL_RTC1307_Bcd2Bin(data[DS1307_MINUTES]);
	time->hours = GCL_RTC1307_Bcd2Bin(data[DS1307_HOURS]);
	time->day = GCL_RTC1307_Bcd2Bin(data[DS1307_DAY]);
	time->date = GCL_RTC1307_Bcd2Bin(data[DS1307_DATE]);
	time->month = GCL_RTC1307_Bcd2Bin(data[DS1307_MONTH]);
	time->year = GCL_RTC1307_Bcd2Bin(data[DS1307_YEAR]);
}

uint8_t GCL_RTC1307_Bin2Bcd(uint8_t bin) {
	uint8_t low = 0;
	uint8_t high = 0;

	/* High nibble */
	high = bin / 10;
	/* Low nibble */
	low = bin - (high * 10);

	/* Return */
	return high << 4 | low;
}

uint8_t GCL_RTC1307_Bcd2Bin(uint8_t bcd) {
	uint8_t dec = 10 * (bcd >> 4);
	dec += bcd & 0x0F;
	return dec;
}

int GCL_RTC1307_Bcd2Bin_int(uint8_t bcd) {
	uint8_t dec = 10 * (bcd >> 4);
	dec += bcd & 0x0F;
	int bck = (int)dec;
	return bck;
}

uint8_t GCL_RTC1307_CheckMinMax(uint8_t val, uint8_t min, uint8_t max) {
	if (val < min) {
		return min;
	} else if (val > max) {
		return max;
	}
	return val;
}

