#include "usb_cdc.h"
#include "FreeRTOS.h"
#include "task.h"
#include "usb_cmds.h"
#include "string.h"
#include "tm_stm32f4_ds1307.h"
#include "I2C_Routines_4xx.h"

__ALIGN_BEGIN USB_OTG_CORE_HANDLE  USB_OTG_dev __ALIGN_END;


extern uint32_t APP_Rx_ptr_out;

extern uint8_t  APP_Rx_Buffer []; /* Write CDC received data in this buffer.
                                     These data will be sent over USB IN endpoint
                                     in the CDC core functions. */
extern uint32_t APP_Rx_ptr_in;    /* Increment this pointer or roll it back to
                                     start address when writing received data
                                     in the buffer APP_Rx_Buffer. */
uint8_t usb_rx[64];

void usb_init(void)
{
	RCC_ClocksTypeDef RCC_Clocks;
	RCC_GetClocksFreq(&RCC_Clocks);
	SysTick_Config(RCC_Clocks.HCLK_Frequency / 1000);
	USBD_Init(&USB_OTG_dev, USB_OTG_FS_CORE_ID, &USR_desc, &USBD_CDC_cb, &USR_cb);
}

/* void usb_cmd_exec(void *pvParameters){
	uint8_t *command =  ( uint8_t * ) pvParameters;
	uint8_t readed_command[64];
	char command_str[65];
	int i;
	for(i=0;i<64;i++){
		readed_command[i]=*(command+i);
		command_str[i] = (char)*(command+i);
	}
	i++;
	command_str[i] = '\0';

	usbprintf("<< ");
	usbprintf(readed_command);
	usbprintf("\n\r");

	if( strcmp(command_str, "test") == 0 ) xTaskCreate( vTaskSimpleCMD, ( signed char * ) "CMD_TEST", configMINIMAL_STACK_SIZE, NULL, 2, ( xTaskHandle * ) NULL);
} */

uint8_t isNum(uint8_t val){
	if (val>47 && val<59) {
		return 1;
	}
	else {
		return 0;
	}

}

uint8_t isArrNum(uint8_t *vals, uint8_t count, uint8_t start){
	uint8_t n = 0;
	uint8_t s = 0;
	for (n=0; n<count; n++) {
		if (vals[(n+start)]>47 && vals[(n+start)]<59) {
			s++;
		}
	}
	if (count==s) {
		return 1;
	}
	else {
		return 0;
	}

}

void usb_cmd_exec(void *pvParameters){
	uint8_t *command =  ( uint8_t * ) pvParameters;
	uint8_t received_command[64];
	char command_str[65];
	int i;
	for(i=0;i<64;i++){
		received_command[i]=*(command+i);
		command_str[i] = (char)*(command+i);
	}
	i++;
	command_str[i] = '\0';

	usbprintf("<< ");
	usbprintf(received_command);
	usbprintf("\n\r");

	if( strcmp(command_str, "test") == 0 ) xTaskCreate( vTaskSimpleCMD, ( signed char * ) "CMD_TEST", configMINIMAL_STACK_SIZE, NULL, 2, ( xTaskHandle * ) NULL);
	if( strncmp(command_str, "!open_valve", 11) == 0 ){
		uint8_t valveId = 255;
		if (command_str[13]>47 && command_str[13]<59) {	// valveId > 9
			valveId = (command_str[13]-48) + 10*(command_str[12]-48);
		}
		else {
			valveId = command_str[12]-48;
		}
		usbprintf("Opening valve...");
		EE_WriteVariable(0x0001,0x0777);
		if (valveId>9) {
			PrintChar((valveId/10)+48);
			PrintChar((valveId%10)+48);
			usbprintf("\n\r");
//			PrintChar((buf[0]/10)+48);
//			PrintChar((buf[0]%10)+48);
		}
		else {
			PrintChar(valveId+48);
			usbprintf("\n\r");
		}

		STM32F4_Discovery_LEDOn(LED3);
	}

	if( strncmp(command_str, "!close_valve", 12) == 0 && command_str[12]==32){
		uint8_t valveId = 255;
		if (command_str[14]>47 && command_str[14]<59) {	// valveId > 9
			valveId = (command_str[14]-48) + 10*(command_str[13]-48);
		}
		else {
			valveId = command_str[13] - 48;
		}
		usbprintf("Closing valve...\n\r");

		STM32F4_Discovery_LEDOff(LED3);
	}

	if( strncmp(command_str, "!eew", 4) == 0 ){
		uint8_t valveId = 255;
		if (command_str[14]>47 && command_str[14]<59) {	// valveId > 9
			valveId = (command_str[14]-48) + 10*(command_str[13]-48);
		}
		else {
			valveId = command_str[13] - 48;
		}
		usbprintf("EEWRITE...\n\r");

		STM32F4_Discovery_LEDOff(LED3);
	}

	if( strncmp(command_str, "!time", 5) == 0 ){
		TM_DS1307_Time_t curtime;
		curtime.hours = 21;
		curtime.minutes = 18;
		curtime.seconds = 0;
		curtime.date = 26;
		curtime.day = 1;
		curtime.month = 5;
		curtime.year = 14;
			uint8_t valveId = 255;
			if (isArrNum(command_str,12,6)) {	// valveId > 9
				// set time
				usbprintf("Setting time...\n\r");

				curtime.hours = (command_str[6]-48)*10+command_str[7]-48;
				curtime.minutes = (command_str[8]-48)*10+command_str[9]-48;
				curtime.seconds = (command_str[10]-48)*10+command_str[11]-48;
				curtime.date = (command_str[12]-48)*10+command_str[13]-48;
				curtime.month = (command_str[14]-48)*10+command_str[15]-48;
				curtime.year = (command_str[16]-48)*10+command_str[17]-48;
				TM_DS1307_SetDateTime(&curtime);
			}
			else {
				// get time
				usbprintf("Current time: ");
				TM_DS1307_GetDateTime(&curtime);

				PrintChar((curtime.hours/10)+48);
				PrintChar((curtime.hours%10)+48);
				usbprintf(":");
				PrintChar((curtime.minutes/10)+48);
				PrintChar((curtime.minutes%10)+48);
				usbprintf(":");
				PrintChar((curtime.seconds/10)+48);
				PrintChar((curtime.seconds%10)+48);
				usbprintf("\n\rDate: ");
				PrintChar((curtime.date/10)+48);
				PrintChar((curtime.date%10)+48);
				usbprintf("-");
				PrintChar((curtime.month/10)+48);
				PrintChar((curtime.month%10)+48);
				usbprintf("-");
				PrintChar((curtime.year/10)+48);
				PrintChar((curtime.year%10)+48);
				usbprintf("\n\r");
			}


			STM32F4_Discovery_LEDOff(LED3);
		}

	if( strncmp(command_str, "!eer", 4) == 0 && command_str[4]==32){
		uint8_t addr = 255;
		addr = command_str[5] - 48;
		if (command_str[6]>47 && command_str[6]<59) {	// valveId > 9
			addr *= 10;
			addr += (command_str[6]-48);
		}
		if (command_str[7]>47 && command_str[7]<59 && addr>9) {
			addr *= 10;
			addr += (command_str[7]-48);
		}
		if (command_str[8]>47 && command_str[8]<59 && addr>99) {
			addr *= 10;
			addr += (command_str[8]-48);
		}
		else {
			usbprintf("Wrong address...\n\r");
		}




		usbprintf("EEPROM Read...\n\r");

		STM32F4_Discovery_LEDOff(LED3);
	}
}

uint8_t findChar(uint8_t *buf, uint8_t start, uint8_t ascii_id){
	uint8_t i = start;
	uint8_t chr = 0;
	while (buf[start] != ascii_id) {
		start++;
	}
	return start;
}

void PrintChar(int c)
{
  APP_Rx_Buffer[APP_Rx_ptr_in] = (uint8_t) c;
  APP_Rx_ptr_in++;
  if(APP_Rx_ptr_in == APP_RX_DATA_SIZE)
  {
    APP_Rx_ptr_in = 0;
  }
}

void usbprintf(char * str){
	int i=0,c=0,exit=0;
	do{
		c = (int)str[i++];
		if( c != 0 ) {
			PrintChar(c);
			delay(10);
		}
		else exit = 1;
	}while( exit==0 );
}
