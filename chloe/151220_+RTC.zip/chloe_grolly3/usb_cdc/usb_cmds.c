#include "usb_cmds.h"
#include "FreeRTOS.h"
#include "task.h"

void vTaskSimpleCMD(void *pvParameters) {
	usbprintf("Simple CMD done\n\r");
	vTaskDelete( NULL );
}
