#ifndef __UTILS_H
#define __UTILS_H

#include "stm32f4_discovery.h"
void delay(int delay);

#endif
